CSCD350-Assignment-4
====================

Setting up group repository.

Team: Triploblastic

Andrew McCall, Richard Sipes, Anna Kravstova, Kevin Raskell